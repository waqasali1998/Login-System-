
<?php
$con= mysqli_connect("localhost","root","","student");

/*if($con){
	echo "Connect";
	}
	else
	{
		echo "Error";
		}
*/
?>
